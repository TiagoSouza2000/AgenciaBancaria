package Programa;

import java.util.Scanner;

//Cliente (nome, endereço, CPF, profissão, renda)
//Conta Pessoal (número e agência)
//Apresentar movimentação bancária (receber, transferir, saldo)

public class Cliente {
	static Scanner sc = new Scanner(System.in);
	
	private static int cont = 1;
	
	private String nome;
	private static String cpf;
	private String endereco;
	private String profissao;
	private double renda;
	
	
	
	public Cliente(String nome, String cpf, String endereco, String profissao, double renda) {
		
		this.nome = nome;
		this.cpf = cpf;
		this.endereco = endereco;
		this.profissao = profissao;
		this.renda = renda;
		cont ++;
		
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCPF() {
		return cpf;
	}
	public void setCPF(String cpf) {
		this.cpf = cpf;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getProfissao() {
		return profissao;
	}
	public void setProfissao(String profissao) {
		this.profissao = profissao;
	}
	public double getRenda() {
		return renda;
	}
	public void setRenda(double renda) {
		this.renda = renda;
	}

	public String toString() {
		return "\nNome: " + this.getNome() +
				"\nInsira seu CPF: " + this.getCPF()  +
		        "\nendereco: " + this.getEndereco()  +
		        "\nProfissao: "+ this.getProfissao() +
		        "\nRenda Mensal: " + this.getRenda();
		
	}
	

public static void Entrar() {
		
		System.out.println("-----------------------------------------------------");
		System.out.println("--------------------SPACE BANK-----------------------");
		System.out.println("-----------------------------------------------------");
		System.out.println("-----------------------------------------------------");
		System.out.println("-------------------------O banco que não tem limites!");
		System.out.println("-----------------------------------------------------");
		System.out.println("Insira seu CPF:--------------------------------------");
		System.out.println("-----------------------------------------------------");
		System.out.println(cpf);
		
		String cpf_pass = sc.next();		
		
		if (cpf_pass.equals(cpf) == true ) {
			Agenciabancaria.operacoes();
		}else {
			System.out.println("CPF INCORRETO!!! Insira novamente:");
			System.out.println("\n");
			Entrar();
			
		}

}
	
}
