package Programa;

import utilitarios.util;


//Cliente (nome, endereço, CPF, profissão, renda)
//Conta Pessoal (número e agência)
//Apresentar movimentação bancária (receber, transferir, saldo)

public class Conta {
	
	private static int contcontas = 1;
	
	private int numeroConta;
	private Cliente cliente;
	private int agencia = 999;
	private Double saldo = 0.0;
	

	public Conta(Cliente cliente) {
		
		this.numeroConta = contcontas;
		this.cliente = cliente;
		this.agencia = agencia;
		contcontas += 1;
	}


	public int getNumeroConta() {
		return numeroConta;
	}


	public void setNumeroConta(int numeroConta) {
		this.numeroConta = numeroConta;
	}


	public Cliente getCliente() {
		return cliente;
	}


	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}


	public int getAgencia() {
		return agencia;
	}


	public void setAgencia(int agencia) {
		this.agencia = agencia;
	}


	public Double getSaldo() {
		return saldo;
	}


	public void setSaldo(Double saldo) {
		this.saldo = saldo;
	}
	
	public String toString() {
		return "\nNome: " + this.cliente.getNome()  +
				"\nNúmero da conta: " + this.getNumeroConta()  +
				"\nAgência: " + this.getAgencia()  +
				"\nCPF: " + this.cliente.getCPF()  +
				"\nProfissão: " + this.cliente.getProfissao()  +
				"\nRenda: " + this.cliente.getRenda() +
				"\nSaldo: " + util.doubleToString(this.getSaldo()) +
				"\n";
			
}

	public void depositar(Double valor) {
		if (valor > 0 ) {
			setSaldo(getSaldo() + valor);
			System.out.println("O depósito foi realizado com Sucesso!");
		}else { 
			System.out.println("Não foi possível realizar o depósito!!!");
			Agenciabancaria.operacoes();
		}
	}
	public void sacar(Double valor) {
		if (valor > 0 && this.getSaldo() >= valor ) {
			setSaldo(getSaldo() - valor);
			System.out.println("O saque foi realizado com Sucesso!");
			Agenciabancaria.operacoes();
		}else { 
			System.out.println("Não foi possível realizar o saque!!!");
		Agenciabancaria.operacoes();			
		}
		}
	public void transferir(Conta contaParaDeposito, Double valor) {
		if (valor > 0 && this.getSaldo() >= valor ) {
			setSaldo(getSaldo() - valor);
			
			contaParaDeposito.saldo = contaParaDeposito.getSaldo() + valor;
			System.out.println("Tranferência realizada com sucesso");
					}else System.out.println("Não foi possível realizar a transferência!!!");
	}
	
	
	
	
}
	
