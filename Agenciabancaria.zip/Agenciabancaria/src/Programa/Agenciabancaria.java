package Programa;

import java.util.ArrayList;
import java.util.Scanner;

public class Agenciabancaria {
	
	static Scanner sc = new Scanner(System.in);
	
	static ArrayList<Conta> contasBancarias;
	
	public static void main(String[] args) {
		contasBancarias = new ArrayList<Conta>();
		login();
		operacoes();
			}

	public static void login() {
		System.out.println("-----------------------------------------------------");
		System.out.println("------------BOAS VINDAS AO SPACE BANK----------------");
		System.out.println("-----------------------------------------------------");
		System.out.println("-----------------------------------------------------");
		System.out.println("-------------------------O banco que não tem limites!");
		System.out.println("-----------------------------------------------------");
		System.out.println("Escolha o tipo de operação desejada:-----------------");
		System.out.println("-----------------------------------------------------");
		System.out.println("| Opção [1] - NOVA CONTA      |");
		System.out.println("| Opção [2] - LOGIN           |");
		System.out.println("| Opção [3] - SAIR            |");
		
		int op_login = sc.nextInt();
		
		switch(op_login) {
		
		case 1:
			criarConta();
			break;
			
		case 2:
			Cliente.Entrar();
			break;
			
		case 3:
			System.out.println("Obrigado, volte sempre!!!");	
			System.exit(0);
			
			default: 
				System.out.println("OPÇÃO INVÁLIDA!!!!");
				System.out.println("\n");
				login();
				break;
		
		}
		
		
	}
		



public static void operacoes() {
	System.out.println("-----------------------------------------------------");
	System.out.println("--------------------SPACE BANK-----------------------");
	System.out.println("-----------------------------------------------------");
	System.out.println("-----------------------------------------------------");
	System.out.println("-------------------------O banco que não tem limites!");
	System.out.println("-----------------------------------------------------");
	System.out.println("Escolha o tipo de operação desejada:-----------------");
	System.out.println("-----------------------------------------------------");
	System.out.println("| Opção [1] - DEPÓSITO        |");
	System.out.println("| Opção [2] - SAQUE           |");
	System.out.println("| Opção [3] - TRANSFERÊNCIAS  |");
	System.out.println("| Opção [4] - DADOS PESSOAIS  |");
	System.out.println("| Opção [5] - LOGOFF          |");
	
	
	int operacao =  sc.nextInt();
	
	switch(operacao) {
	case 1:
		deposito();
		break;
	
	case 2:
		saque();
		break;
	
	case 3:
		transferir();
		break;
	
	case 4:
		listarContas();
		break;
	
	case 5:
		System.out.println("Obrigado, volte sempre!!!");	
		System.out.println("\n");
		login();
		
		break;
	
	default: 
		System.out.println("OPÇÃO INVÁLIDA!!!!");
		System.out.println("\n");
		operacoes();
		break;
	}
}
	
	public static void criarConta(){
		
		System.out.println("\nNome: ");
		String nome = sc.next();
		
		System.out.println("\nCPF: ");
		String cpf = sc.next();
		
		System.out.println("\nEndereço: ");
		String endereco = sc.next();
		
		System.out.println("\nProfissão: ");
		String profissao = sc.next();
		
		System.out.println("\nRenda: ");
		Double renda = sc.nextDouble();
		 
		Cliente cliente = new Cliente(nome, cpf, endereco, profissao, renda);
		
		Conta conta = new Conta(cliente);
		
		contasBancarias.add(conta);
		
		System.out.println("Sua conta foi criada com sucesso!!!");
		System.out.println("\n");
		operacoes();
		
	}
	
	private static Conta encontrarConta(int numeroConta) {
		Conta conta = null;
		if (contasBancarias.size() > 0) {
			for(Conta conta1: contasBancarias) {
				if(conta1.getNumeroConta() == numeroConta) {
					conta = conta1;
			}
		}
		}
		return conta;
	}
	
	public static void deposito() {
		System.out.println("Insira o número da conta para depósito: ");
		int numeroConta = sc.nextInt();
		
		Conta conta = encontrarConta(numeroConta);
		
		if (conta != null) {
			System.out.println("Qual o valor a ser depositado?");
			Double valorDeposito = sc.nextDouble();
			conta.depositar(valorDeposito);
			
		}else {
			System.out.println("CONTA NÃO ENCONTRADA!!!");
		}
		operacoes();
		
	}
	
	public static void saque(){
		System.out.println("Insira o número da conta para sacar");
		int numeroConta = sc.nextInt();
		
		Conta conta = encontrarConta(numeroConta);
		
		if(conta != null) {
			System.out.println("Qual o valor a ser sacado?");
			Double valorSaque = sc.nextDouble();
			conta.sacar(valorSaque);
			System.out.println("Valor sacado com sucesso!!!");
			
		}else {
			System.out.println("CONTA NÃO ENCONTRADA!!!");
		}
	}
	
	public static void transferir() {
		System.out.println("Número da conta a enviar: ");
		int numeroContaRemetente = sc.nextInt();
		
		Conta contaRemetente = encontrarConta(numeroContaRemetente);
		
		if (contaRemetente != null) {
			System.out.println("Número da conta a receber");
			int numeroContaDestinatario = sc.nextInt();
			
			Conta contaDestinatario = encontrarConta(numeroContaDestinatario);
			
			if(numeroContaDestinatario != 0) {
				System.out.println("Valor da transferência: ");
				Double valor = sc.nextDouble();
				
				contaRemetente.transferir(contaDestinatario, valor);
			}
		}
		operacoes();
	}
	
	public static void listarContas() {
		if(contasBancarias.size() > 0) {
			for(Conta conta: contasBancarias) {
				System.out.println(conta);
			}
			
			}else {
				System.out.println("Não há contas cadastradas!");
		}
	operacoes();
	}
		
}



